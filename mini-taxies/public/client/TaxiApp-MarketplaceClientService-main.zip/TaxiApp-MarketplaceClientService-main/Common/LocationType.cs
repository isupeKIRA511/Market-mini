namespace Marketplace.Common;



public class LocationType
{
    public required double Latitude {get; set;}
    public required double Longitude {get; set;}
}

