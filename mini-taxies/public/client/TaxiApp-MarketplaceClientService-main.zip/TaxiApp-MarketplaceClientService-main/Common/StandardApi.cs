using System.ComponentModel.DataAnnotations;

namespace Marketplace.Common;



public class ApiGetManyResponse<DATA>
{
    public required bool Success {get; set;}
    public required int PageSize {get; set;}
    public required int TotalCount { get; set; }
    public required int PageNum {get; set;}
    public required List<DATA> Data {get; set;}

    public required string Message {get; set;}
}



public class ApiGetManyRequest
{
    [Range(1, 100)]
    public required int PageSize {get; set;}
    [Range(1, int.MaxValue)]
    public required int PageNum {get; set;}

    public string? Term {get; set;}
    public string? Type {get; set;}

    public DateTime? StartDate {get; set;}
    public DateTime? EndDate {get; set;}
}



public class ApiGetOneResponse<DATA>
{
    public required bool Success {get; set;}
    public required DATA Data {get; set;}
    public required string Message {get; set;}
}



public class ApiGetOneRequest<ID>
{
    public required ID Id {get; set;}
    public required string Type {get; set;}
}



public class ApiStatusResponse
{
    public required bool Success {get; set;} 
    public required string Message {get; set;}
    public required int Code {get; set;}
}
