using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using Marketplace.Common;

namespace Marketplace.Features.Cars;

[ApiController]
[Route("marketplace/api/v1/[controller]")]
public class CarController(ICarService service) : ControllerBase
{
    private readonly ICarService _service = service;

    [HttpGet]
    [Authorize]
    public async Task<IActionResult> GetAll([FromQuery] ApiGetManyRequest request)
    {
        var result = await _service.GetAllCarsAsync(request);
        return Ok(new ApiGetManyResponse<CarModel>
        {
            Success = true,
            PageNum = request.PageNum,
            PageSize = request.PageSize,
            TotalCount = result.TotalCount,
            Data = result.Data,
            Message = "Cars retrieved successfully"
        });
    }

    [HttpGet("{id:guid}")]
    [Authorize]
    public async Task<IActionResult> Get(Guid id)
    {
        var car = await _service.GetCarAsync(id);
        if (car == null)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Car not found" });
            
        return Ok(new ApiGetOneResponse<CarModel>
        {
            Success = true,
            Data = car,
            Message = "Car retrieved successfully"
        });
    }

    [HttpPost]
    [Authorize]
    public async Task<IActionResult> Create([FromBody] Car car)
    {
        var userIdStr = User.FindFirst(ClaimTypes.NameIdentifier)?.Value 
                        ?? User.FindFirst(System.IdentityModel.Tokens.Jwt.JwtRegisteredClaimNames.Sub)?.Value;
                        
        if (!Guid.TryParse(userIdStr, out var ownerId))
        {
            return Unauthorized(new ApiStatusResponse { Success = false, Code = 401, Message = "Invalid user ID or user not logged in" });
        }

        var createdCar = await _service.CreateCarAsync(car, ownerId);
        return Ok(new ApiGetOneResponse<CarModel>
        {
            Success = true,
            Data = createdCar,
            Message = "Car created successfully"
        });
    }

    [HttpPut("{id:guid}")]
    [Authorize]
    public async Task<IActionResult> Update(Guid id, [FromBody] Car car)
    {
        var updated = await _service.UpdateCarAsync(id, car);
        if (!updated)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Car not found" });

        return Ok(new ApiStatusResponse { Success = true, Code = 200, Message = "Car updated successfully" });
    }

    [HttpDelete("{id:guid}")]
    [Authorize]
    public async Task<IActionResult> Delete(Guid id)
    {
        var deleted = await _service.DeleteCarAsync(id);
        if (!deleted)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Car not found" });

        return Ok(new ApiStatusResponse { Success = true, Code = 200, Message = "Car deleted successfully" });
    }

    [HttpPatch("{id:guid}/comfort-score")]
    [Authorize]
    public async Task<IActionResult> ChangeComfortScore(Guid id, [FromBody] UpdateComfortScoreRequest request)
    {
        var updated = await _service.ChangeCarComfortScoreAsync(id, request.ComfortScore);
        if (!updated)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Car not found" });

        return Ok(new ApiStatusResponse { Success = true, Code = 200, Message = "Car comfort score updated successfully" });
    }

    [HttpPatch("{id:guid}/owner")]
    [Authorize]
    public async Task<IActionResult> ChangeOwner(Guid id, [FromBody] UpdateCarOwnerRequest request)
    {
        var updated = await _service.ChangeCarOwnerAsync(id, request.NewOwnerId);
        if (!updated)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Car not found" });

        return Ok(new ApiStatusResponse { Success = true, Code = 200, Message = "Car owner updated successfully" });
    }
}
