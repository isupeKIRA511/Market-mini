namespace Marketplace.Features.Cars;



public class Car {
    public required string Model {set; get;}
    public required string Brand {set; get;}

    public required string LicensePlate {set; get;}
}



public class CarModel : Car {
    public required Guid OwnerId {get; set;}
    public required Guid Id {set; get;}
    public int ComfortScore {set; get;} = 1;
    public required DateTime CreatedAt {set; get;}
    public DateTime? DeletedAt {set; get;}
}
