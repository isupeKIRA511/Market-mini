namespace Marketplace.Features.Cars;

public record UpdateCarOwnerRequest(Guid NewOwnerId);
public record UpdateComfortScoreRequest(int ComfortScore);