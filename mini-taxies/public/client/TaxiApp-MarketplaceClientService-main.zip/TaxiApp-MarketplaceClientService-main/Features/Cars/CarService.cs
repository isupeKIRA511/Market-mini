using Microsoft.EntityFrameworkCore;
using Marketplace.Engine;
using Marketplace.Common;

namespace Marketplace.Features.Cars;

public interface ICarService
{
    Task<CarModel?> GetCarAsync(Guid id);
    Task<(List<CarModel> Data, int TotalCount)> GetAllCarsAsync(ApiGetManyRequest request);
    Task<CarModel> CreateCarAsync(Car car, Guid owner_id);
    Task<bool> UpdateCarAsync(Guid id, Car car);
    Task<bool> DeleteCarAsync(Guid id);
    public Task<bool> ChangeCarComfortScoreAsync(Guid id, int comfort_score);
    public Task<bool> ChangeCarOwnerAsync(Guid id, Guid new_owner_id);
}

public class CarService(IMarketplaceDbContext dbContext) : ICarService
{
    private readonly IMarketplaceDbContext _dbContext = dbContext;

    public async Task<CarModel?> GetCarAsync(Guid id)
    {
        return await _dbContext.Cars.FindAsync(id);
    }

    public async Task<(List<CarModel> Data, int TotalCount)> GetAllCarsAsync(ApiGetManyRequest request)
    {
        var query = _dbContext.Cars.AsQueryable();

        if (!string.IsNullOrEmpty(request.Term))
        {
            query = query.Where(c => 
                (c.Model != null && c.Model.Contains(request.Term)) || 
                (c.Brand != null && c.Brand.Contains(request.Term)) || 
                (c.LicensePlate != null && c.LicensePlate.Contains(request.Term)));
        }

        int totalCount = await query.CountAsync();

        var data = await query
            .Skip((request.PageNum - 1) * request.PageSize)
            .Take(request.PageSize)
            .ToListAsync();

        return (data, totalCount);
    }

    public async Task<CarModel> CreateCarAsync(Car car, Guid owner_id)
    {
        CarModel car_model = new()
        {
            Id = Guid.NewGuid(),
            Model = car.Model,
            Brand = car.Brand,
            LicensePlate = car.LicensePlate,
            CreatedAt = DateTime.UtcNow,
            OwnerId = owner_id
        };

        _dbContext.Cars.Add(car_model);
        await _dbContext.SaveChangesAsync(default);
        return car_model;
    }

    public async Task<bool> UpdateCarAsync(Guid id, Car car)
    {
        var existingCar = await _dbContext.Cars.FindAsync(id);
        if (existingCar == null)
            return false;

        existingCar.Model = car.Model;
        existingCar.Brand = car.Brand;
        existingCar.LicensePlate = car.LicensePlate;

        await _dbContext.SaveChangesAsync(default);
        return true;
    }

    public async Task<bool> ChangeCarComfortScoreAsync(Guid id, int comfort_score)
    {
        var existingCar = await _dbContext.Cars.FindAsync(id);
        if (existingCar == null)
            return false;

        existingCar.ComfortScore = comfort_score;

        await _dbContext.SaveChangesAsync(default);
        return true;
    }

    public async Task<bool> ChangeCarOwnerAsync(Guid id, Guid new_owner_id)
    {
        var existingCar = await _dbContext.Cars.FindAsync(id);
        if (existingCar == null)
            return false;

        existingCar.OwnerId = new_owner_id;

        await _dbContext.SaveChangesAsync(default);
        return true;
    }

    public async Task<bool> DeleteCarAsync(Guid id)
    {
        var existingCar = await _dbContext.Cars.FindAsync(id);
        if (existingCar == null)
            return false;

        existingCar.DeletedAt = DateTime.UtcNow;
        await _dbContext.SaveChangesAsync(default);
        return true;
    }
}
