using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace Marketplace.Features.Auth;

public class JwtTokenGenerator(IConfiguration configuration) : IJwtTokenGenerator
{
    public string GenerateToken(UserRecord user)
    {
        // 1. Define the Claims (The Payload)
        var claims = new List<Claim>
        {
            new(  JwtRegisteredClaimNames.Sub, user.Id.ToString()  ), // Standard Subject Claim
            new(  JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()  ), // Unique Token ID
            new(  ClaimTypes.Role, user.Role.ToString()  )
        };

        // 2. Get the Secret Key (MUST be long and complex)
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["JwtSettings:Secret"]!));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        // 3. Create the Token Object
        var token = new JwtSecurityToken(
            issuer: configuration["JwtSettings:Issuer"],
            audience: configuration["JwtSettings:Audience"],
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(int.Parse(configuration["JwtSettings:ExpiryMinutes"]!)),
            signingCredentials: creds
        );

        // 4. Write it as a string
        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}