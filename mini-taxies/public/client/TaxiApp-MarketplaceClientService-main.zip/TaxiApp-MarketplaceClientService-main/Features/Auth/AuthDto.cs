namespace Marketplace.Features.Auth;


public class RegisterRequest
{
    public required string PhoneNumber { get; set; } = string.Empty;
    public required string FullName { get; set; } = string.Empty;
    public required string Password { get; set; } = string.Empty;
}

public record LoginRequest(string PhoneNumber , string Password);

public record AuthResponse(Guid Id, string PhoneNumber, string Token);
