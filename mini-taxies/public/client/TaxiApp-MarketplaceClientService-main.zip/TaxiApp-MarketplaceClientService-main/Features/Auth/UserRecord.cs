namespace Marketplace.Features.Auth;


public record UserRecord( Guid Id, string Role );
