using Marketplace.Engine;
using Marketplace.Features.Customers;
using Microsoft.EntityFrameworkCore;
using LoginRequest = Marketplace.Features.Auth.LoginRequest;

namespace Marketplace.Features.Auth;

public interface IAuthService
{
    Task<AuthResponse> LoginAsync(LoginRequest request, string role);
    Task<AuthResponse> RegisterAsync(RegisterRequest request, string role);

    Task<CustomerModel?> ValidateUserCredentials(string email, string password);
}

public class AuthService(IMarketplaceDbContext context, IPasswordHasher hasher, IJwtTokenGenerator tokenGenerator)
    : IAuthService
{
    public async Task<AuthResponse> LoginAsync(LoginRequest request, string role)
    {
        var user = await ValidateUserCredentials(request.PhoneNumber, request.Password) ?? throw new Exception("Invalid Credentials");
        
        var token = tokenGenerator.GenerateToken(  new UserRecord(user.Id , role)  );

        return new AuthResponse(user.Id, user.PhoneNumber, token);
    }

    public async Task<AuthResponse> RegisterAsync(RegisterRequest request, string role)
    {
        var normalizedPhoneNumber = request.PhoneNumber.Trim().ToLower();
        if (await context.Customers.AnyAsync(u => u.PhoneNumber == normalizedPhoneNumber))
            throw new Exception("User already exists");

        var user = new CustomerModel
        {
            Id = Guid.NewGuid(),
            PhoneNumber = normalizedPhoneNumber,
            FullName = request.FullName,
            PasswordHash = hasher.Hash(request.Password)
        };

        context.Customers.Add(user);
        await context.SaveChangesAsync(default);

        // 3. Auto-login after register (OR not depend on use case)
        var token = tokenGenerator.GenerateToken(  new UserRecord(user.Id, role)  );
        return new AuthResponse(user.Id, user.PhoneNumber, token);
    }


    public async Task<CustomerModel?> ValidateUserCredentials(string phone_number, string password)
    {
        var normalizedPhoneNumber = phone_number.Trim().ToLower();
        var user = await context.Customers.FirstOrDefaultAsync(u => u.PhoneNumber == normalizedPhoneNumber);
        if (user is null)
            return null;

        bool isValid = hasher.Verify(password, user.PasswordHash);
        return !isValid ? null : user;
    }
}
