namespace Marketplace.Features.Auth;



public interface IJwtTokenGenerator
{
    string GenerateToken(UserRecord user);
}
