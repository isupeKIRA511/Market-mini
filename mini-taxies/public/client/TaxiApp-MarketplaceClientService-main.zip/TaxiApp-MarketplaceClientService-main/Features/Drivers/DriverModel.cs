namespace Marketplace.Features.Drivers;


public class DriverModel {
    public required Guid Id {set; get;}
    public required string Name {set; get;}
    public required DateTime CreatedAt {set; get;}
    public DateTime? DeletedAt {set; get;}
}
