using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Marketplace.Engine;
using Marketplace.Common;

namespace Marketplace.Features.Companies;

public interface ICompanyService
{
    Task<CompanyModel?> GetCompanyAsync(Guid id);
    Task<(List<CompanyModel> Data, int TotalCount)> GetAllCompaniesAsync(ApiGetManyRequest request);
    Task<CompanyModel> CreateCompanyAsync(CompanyModel company);
    Task<bool> UpdateCompanyAsync(Guid id, CompanyModel company);
    Task<bool> DeleteCompanyAsync(Guid id);
}

public class CompanyService(IMarketplaceDbContext dbContext) : ICompanyService
{
    private readonly IMarketplaceDbContext _dbContext = dbContext;

    public async Task<CompanyModel?> GetCompanyAsync(Guid id)
    {
        return await _dbContext.Companies.FindAsync(id);
    }

    public async Task<(List<CompanyModel> Data, int TotalCount)> GetAllCompaniesAsync(ApiGetManyRequest request)
    {
        var query = _dbContext.Companies.AsQueryable();

        if (!string.IsNullOrEmpty(request.Term) && (string.IsNullOrEmpty(request.Type) || request.Type.Equals("Name", StringComparison.OrdinalIgnoreCase)))
        {
            query = query.Where(c => EF.Functions.Like(c.Name, $"%{request.Term}%"));
        }

        int totalCount = await query.CountAsync();

        var data = await query
            .OrderByDescending(c => c.CreatedAt)
            .Skip((request.PageNum - 1) * request.PageSize)
            .Take(request.PageSize)
            .ToListAsync();

        return (data, totalCount);
    }

    public async Task<CompanyModel> CreateCompanyAsync(CompanyModel company)
    {
        _dbContext.Companies.Add(company);
        await _dbContext.SaveChangesAsync(default);
        return company;
    }

    public async Task<bool> UpdateCompanyAsync(Guid id, CompanyModel company)
    {
        var existingCompany = await _dbContext.Companies.FindAsync(id);
        if (existingCompany == null)
            return false;

        existingCompany.Name = company.Name;
        existingCompany.Status = company.Status;
        existingCompany.ReputationScore = company.ReputationScore;

        await _dbContext.SaveChangesAsync(default);
        return true;
    }

    public async Task<bool> DeleteCompanyAsync(Guid id)
    {
        var existingCompany = await _dbContext.Companies.FindAsync(id);
        if (existingCompany == null)
            return false;

        _dbContext.Companies.Remove(existingCompany);
        await _dbContext.SaveChangesAsync(default);
        return true;
    }
}
