namespace Marketplace.Features.Companies;



public class CompanyModel {
    public required Guid Id {set; get;}
    public required string Name {set; get;}
    public required bool Status {set; get;}

    public required int ReputationScore {set; get;}

    public required DateTime CreatedAt {set; get;}
    public DateTime DeletedAt {set; get;}
}