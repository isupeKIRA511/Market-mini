
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Marketplace.Common;

namespace Marketplace.Features.Companies;

[ApiController]
[Route("marketplace/api/v1/[controller]")]
public class CompanyController(ICompanyService service) : ControllerBase
{
    private readonly ICompanyService _service = service;

    [HttpGet]
    [Authorize]
    public async Task<IActionResult> GetAll([FromQuery] ApiGetManyRequest request)
    {
        var (Data, TotalCount) = await _service.GetAllCompaniesAsync(request);
        return Ok(new ApiGetManyResponse<CompanyModel>
        {
            Success = true,
            PageNum = request.PageNum,
            PageSize = request.PageSize,
            TotalCount = TotalCount,
            Data = Data,
            Message = "Companies retrieved successfully"
        });
    }

    [HttpGet("{id:guid}")]
    [Authorize]
    public async Task<IActionResult> Get(Guid id)
    {
        var company = await _service.GetCompanyAsync(id);
        if (company == null)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Company not found" });
            
        return Ok(new ApiGetOneResponse<CompanyModel>
        {
            Success = true,
            Data = company,
            Message = "Company retrieved successfully"
        });
    }

    [HttpPost]
    [Authorize]
    public async Task<IActionResult> Create([FromBody] CompanyModel company)
    {
        var createdCompany = await _service.CreateCompanyAsync(company);
        return Ok(new ApiGetOneResponse<CompanyModel>
        {
            Success = true,
            Data = createdCompany,
            Message = "Company created successfully"
        });
    }

    [HttpPut("{id:guid}")]
    [Authorize]
    public async Task<IActionResult> Update(Guid id, [FromBody] CompanyModel company)
    {
        if (id != company.Id)
            return BadRequest(new ApiStatusResponse { Success = false, Code = 400, Message = "ID mismatch" });

        var updated = await _service.UpdateCompanyAsync(id, company);
        if (!updated)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Company not found" });

        return Ok(new ApiStatusResponse { Success = true, Code = 200, Message = "Company updated successfully" });
    }

    [HttpDelete("{id:guid}")]
    [Authorize]
    public async Task<IActionResult> Delete(Guid id)
    {
        var deleted = await _service.DeleteCompanyAsync(id);
        if (!deleted)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Company not found" });

        return Ok(new ApiStatusResponse { Success = true, Code = 200, Message = "Company deleted successfully" });
    }
}
