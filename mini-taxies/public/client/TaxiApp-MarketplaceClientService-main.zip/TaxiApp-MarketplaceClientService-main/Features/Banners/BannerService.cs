using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Marketplace.Engine;
using Marketplace.Common;

namespace Marketplace.Features.Banners;

public interface IBannerService
{
    Task<BannerModel?> GetBannerAsync(Guid id);
    Task<(List<BannerModel> Data, int TotalCount)> GetAllBannersAsync(ApiGetManyRequest request);
    Task<BannerModel> CreateBannerAsync(BannerModel banner);
    Task<bool> UpdateBannerAsync(Guid id, BannerModel banner);
    Task<bool> DeleteBannerAsync(Guid id);
}

public class BannerService(IMarketplaceDbContext dbContext) : IBannerService
{
    private readonly IMarketplaceDbContext _dbContext = dbContext;

    public async Task<BannerModel?> GetBannerAsync(Guid id)
    {
        return await _dbContext.Banners.FindAsync(id);
    }

    public async Task<(List<BannerModel> Data, int TotalCount)> GetAllBannersAsync(ApiGetManyRequest request)
    {
        var query = _dbContext.Banners.AsQueryable();

        if (!string.IsNullOrEmpty(request.Term))
        {
            query = query.Where(b => b.Type.Contains(request.Term));
        }

        int totalCount = await query.CountAsync();

        var data = await query
            .Skip((request.PageNum - 1) * request.PageSize)
            .Take(request.PageSize)
            .ToListAsync();

        return (data, totalCount);
    }

    public async Task<BannerModel> CreateBannerAsync(BannerModel banner)
    {
        banner.Id = Guid.NewGuid();
        banner.CreatedAt = DateTime.UtcNow;
        _dbContext.Banners.Add(banner);
        await _dbContext.SaveChangesAsync(default);
        return banner;
    }

    public async Task<bool> UpdateBannerAsync(Guid id, BannerModel banner)
    {
        var existingBanner = await _dbContext.Banners.FindAsync(id);
        if (existingBanner == null)
            return false;

        existingBanner.Type = banner.Type;
        
        await _dbContext.SaveChangesAsync(default);
        return true;
    }

    public async Task<bool> DeleteBannerAsync(Guid id)
    {
        var existingBanner = await _dbContext.Banners.FindAsync(id);
        if (existingBanner == null)
            return false;

        existingBanner.DeletedAt = DateTime.UtcNow;
        // Or hard delete: _dbContext.Banners.Remove(existingBanner);
        // Matching other features which do hard delete
        _dbContext.Banners.Remove(existingBanner);
        await _dbContext.SaveChangesAsync(default);
        return true;
    }
}
