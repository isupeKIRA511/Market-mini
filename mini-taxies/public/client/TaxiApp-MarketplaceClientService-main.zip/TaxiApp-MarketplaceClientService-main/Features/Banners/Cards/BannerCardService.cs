using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Marketplace.Engine;
using Marketplace.Common;

namespace Marketplace.Features.Banners.Cards;

public interface IBannerCardService
{
    Task<BannerCardModel?> GetBannerCardAsync(Guid id);
    Task<(List<BannerCardModel> Data, int TotalCount)> GetAllBannerCardsAsync(ApiGetManyRequest request);
    Task<BannerCardModel> CreateBannerCardAsync(BannerCardModel bannerCard);
    Task<bool> UpdateBannerCardAsync(Guid id, BannerCardModel bannerCard);
    Task<bool> DeleteBannerCardAsync(Guid id);
}

public class BannerCardService(IMarketplaceDbContext dbContext) : IBannerCardService
{
    private readonly IMarketplaceDbContext _dbContext = dbContext;

    public async Task<BannerCardModel?> GetBannerCardAsync(Guid id)
    {
        return await _dbContext.BannerCards.FindAsync(id);
    }

    public async Task<(List<BannerCardModel> Data, int TotalCount)> GetAllBannerCardsAsync(ApiGetManyRequest request)
    {
        var query = _dbContext.BannerCards.AsQueryable();

        if (!string.IsNullOrEmpty(request.Term))
        {
            query = query.Where(bc => 
                (bc.Title != null && bc.Title.Contains(request.Term)) || 
                (bc.Description != null && bc.Description.Contains(request.Term)));
        }

        int totalCount = await query.CountAsync();

        var data = await query
            .Skip((request.PageNum - 1) * request.PageSize)
            .Take(request.PageSize)
            .ToListAsync();

        return (data, totalCount);
    }

    public async Task<BannerCardModel> CreateBannerCardAsync(BannerCardModel bannerCard)
    {
        bannerCard.Id = Guid.NewGuid();
        _dbContext.BannerCards.Add(bannerCard);
        await _dbContext.SaveChangesAsync(default);
        return bannerCard;
    }

    public async Task<bool> UpdateBannerCardAsync(Guid id, BannerCardModel bannerCard)
    {
        var existingBannerCard = await _dbContext.BannerCards.FindAsync(id);
        if (existingBannerCard == null)
            return false;

        existingBannerCard.Title = bannerCard.Title;
        existingBannerCard.Subtitle = bannerCard.Subtitle;
        existingBannerCard.Description = bannerCard.Description;
        existingBannerCard.ImageUrl = bannerCard.ImageUrl;
        existingBannerCard.Price = bannerCard.Price;
        existingBannerCard.ParentBannerId = bannerCard.ParentBannerId;
        existingBannerCard.OnClick = bannerCard.OnClick;

        await _dbContext.SaveChangesAsync(default);
        return true;
    }

    public async Task<bool> DeleteBannerCardAsync(Guid id)
    {
        var existingBannerCard = await _dbContext.BannerCards.FindAsync(id);
        if (existingBannerCard == null)
            return false;

        _dbContext.BannerCards.Remove(existingBannerCard);
        await _dbContext.SaveChangesAsync(default);
        return true;
    }
}
