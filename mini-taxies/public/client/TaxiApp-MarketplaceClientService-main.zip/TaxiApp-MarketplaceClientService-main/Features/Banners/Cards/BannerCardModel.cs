namespace Marketplace.Features.Banners.Cards;



public class BannerCardModel {
    public Guid Id { get; set; }
    public string? Title {get; set;}
    public string? Subtitle {get; set;}

    public string? Description {get; set;}
    public string? ImageUrl {get; set;}
    public string? Price {get; set;}

    public Guid ParentBannerId {get; set;}

    public string? OnClick {get; set;}
}

