using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Marketplace.Common;

namespace Marketplace.Features.Banners.Cards;

[ApiController]
[Route("marketplace/api/v1/[controller]")]
public class BannerCardController(IBannerCardService service) : ControllerBase
{
    private readonly IBannerCardService _service = service;

    [HttpGet]
    [Authorize]
    public async Task<IActionResult> GetAll([FromQuery] ApiGetManyRequest request)
    {
        var (Data, TotalCount) = await _service.GetAllBannerCardsAsync(request);
        return Ok(new ApiGetManyResponse<BannerCardModel>
        {
            Success = true,
            PageNum = request.PageNum,
            PageSize = request.PageSize,
            TotalCount = TotalCount,
            Data = Data,
            Message = "Banner cards retrieved successfully"
        });
    }

    [HttpGet("{id:guid}")]
    [Authorize]
    public async Task<IActionResult> Get(Guid id)
    {
        var bannerCard = await _service.GetBannerCardAsync(id);
        if (bannerCard == null)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Banner card not found" });
            
        return Ok(new ApiGetOneResponse<BannerCardModel>
        {
            Success = true,
            Data = bannerCard,
            Message = "Banner card retrieved successfully"
        });
    }

    [HttpPost]
    [Authorize]
    public async Task<IActionResult> Create([FromBody] BannerCardModel bannerCard)
    {
        var createdBannerCard = await _service.CreateBannerCardAsync(bannerCard);
        return Ok(new ApiGetOneResponse<BannerCardModel>
        {
            Success = true,
            Data = createdBannerCard,
            Message = "Banner card created successfully"
        });
    }

    [HttpPut("{id:guid}")]
    [Authorize]
    public async Task<IActionResult> Update(Guid id, [FromBody] BannerCardModel bannerCard)
    {
        if (id != bannerCard.Id)
            return BadRequest(new ApiStatusResponse { Success = false, Code = 400, Message = "ID mismatch" });

        var updated = await _service.UpdateBannerCardAsync(id, bannerCard);
        if (!updated)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Banner card not found" });

        return Ok(new ApiStatusResponse { Success = true, Code = 200, Message = "Banner card updated successfully" });
    }

    [HttpDelete("{id:guid}")]
    [Authorize]
    public async Task<IActionResult> Delete(Guid id)
    {
        var deleted = await _service.DeleteBannerCardAsync(id);
        if (!deleted)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Banner card not found" });

        return Ok(new ApiStatusResponse { Success = true, Code = 200, Message = "Banner card deleted successfully" });
    }
}
