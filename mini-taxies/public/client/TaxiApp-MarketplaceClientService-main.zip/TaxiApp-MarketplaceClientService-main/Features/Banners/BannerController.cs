using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Marketplace.Common;

namespace Marketplace.Features.Banners;

[ApiController]
[Route("marketplace/api/v1/[controller]")]
public class BannerController(IBannerService service) : ControllerBase
{
    private readonly IBannerService _service = service;

    [HttpGet]
    [Authorize]
    public async Task<IActionResult> GetAll([FromQuery] ApiGetManyRequest request)
    {
        var (Data, TotalCount) = await _service.GetAllBannersAsync(request);
        return Ok(new ApiGetManyResponse<BannerModel>
        {
            Success = true,
            PageNum = request.PageNum,
            PageSize = request.PageSize,
            TotalCount = TotalCount,
            Data = Data,
            Message = "Banners retrieved successfully"
        });
    }

    [HttpGet("{id:guid}")]
    [Authorize]
    public async Task<IActionResult> Get(Guid id)
    {
        var banner = await _service.GetBannerAsync(id);
        if (banner == null)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Banner not found" });
            
        return Ok(new ApiGetOneResponse<BannerModel>
        {
            Success = true,
            Data = banner,
            Message = "Banner retrieved successfully"
        });
    }

    [HttpPost]
    [Authorize]
    public async Task<IActionResult> Create([FromBody] BannerModel banner)
    {
        var createdBanner = await _service.CreateBannerAsync(banner);
        return Ok(new ApiGetOneResponse<BannerModel>
        {
            Success = true,
            Data = createdBanner,
            Message = "Banner created successfully"
        });
    }

    [HttpPut("{id:guid}")]
    [Authorize]
    public async Task<IActionResult> Update(Guid id, [FromBody] BannerModel banner)
    {
        if (id != banner.Id)
            return BadRequest(new ApiStatusResponse { Success = false, Code = 400, Message = "ID mismatch" });

        var updated = await _service.UpdateBannerAsync(id, banner);
        if (!updated)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Banner not found" });

        return Ok(new ApiStatusResponse { Success = true, Code = 200, Message = "Banner updated successfully" });
    }

    [HttpDelete("{id:guid}")]
    [Authorize]
    public async Task<IActionResult> Delete(Guid id)
    {
        var deleted = await _service.DeleteBannerAsync(id);
        if (!deleted)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Banner not found" });

        return Ok(new ApiStatusResponse { Success = true, Code = 200, Message = "Banner deleted successfully" });
    }
}
