namespace Marketplace.Features.Banners;




public class BannerModel {
    public required Guid Id {set; get;}

    public required string Type {set; get;}

    public required DateTime CreatedAt {set; get;}
    public DateTime DeletedAt {set; get;}
}


