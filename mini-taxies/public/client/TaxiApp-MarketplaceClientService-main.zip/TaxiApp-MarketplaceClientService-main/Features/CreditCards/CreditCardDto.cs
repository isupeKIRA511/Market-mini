namespace Marketplace.Features.CreditCards;

public class CreditCardFormRequest {
    public required int CVE {set; get;}
    public required int Expiration {set; get;}
    public required string CardNumber {set; get;}
    public required string CardHolderName {set; get;}
}