namespace Marketplace.Features.CreditCards;


public class CreditCardModel {
    public required Guid Id {set; get;}
    public required int Owner_Id {set; get;}


    public required int CVE {set; get;}
    public required int Expiration {set; get;}
    public required string CardNumber {set; get;}
    public required string CardHolderName {set; get;}


    public required DateTime CreatedAt {set; get;}
    public DateTime DeletedAt {set; get;}
}