using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Marketplace.Engine;
using Marketplace.Common;

namespace Marketplace.Features.CreditCards;

public interface ICreditCardService
{
    Task<CreditCardModel?> GetCreditCardAsync(Guid id);
    Task<(List<CreditCardModel> Data, int TotalCount)> GetAllCreditCardsAsync(ApiGetManyRequest request);
    Task<CreditCardModel> CreateCreditCardAsync(int ownerId, CreditCardFormRequest request);
    Task<bool> DeleteCreditCardAsync(Guid id);
}

public class CreditCardService(IMarketplaceDbContext dbContext) : ICreditCardService
{
    private readonly IMarketplaceDbContext _dbContext = dbContext;

    public async Task<CreditCardModel?> GetCreditCardAsync(Guid id)
    {
        return await _dbContext.CreditCards.FirstOrDefaultAsync(c => c.Id == id && c.DeletedAt == default);
    }

    public async Task<(List<CreditCardModel> Data, int TotalCount)> GetAllCreditCardsAsync(ApiGetManyRequest request)
    {
        var query = _dbContext.CreditCards.Where(c => c.DeletedAt == default);

        var totalCount = await query.CountAsync();

        var data = await query
            .Skip((request.PageNum - 1) * request.PageSize)
            .Take(request.PageSize)
            .ToListAsync();

        return (data, totalCount);
    }

    public async Task<CreditCardModel> CreateCreditCardAsync(int ownerId, CreditCardFormRequest request)
    {
        var creditCard = new CreditCardModel
        {
            Id = Guid.NewGuid(),
            Owner_Id = ownerId,
            CVE = request.CVE,
            Expiration = request.Expiration,
            CardNumber = request.CardNumber,
            CardHolderName = request.CardHolderName,
            CreatedAt = DateTime.UtcNow
        };

        _dbContext.CreditCards.Add(creditCard);
        await _dbContext.SaveChangesAsync(default);

        return creditCard;
    }

    public async Task<bool> DeleteCreditCardAsync(Guid id)
    {
        var creditCard = await _dbContext.CreditCards.FindAsync(id);
        if (creditCard == null || creditCard.DeletedAt != default)
            return false;

        // Soft delete
        creditCard.DeletedAt = DateTime.UtcNow;
        await _dbContext.SaveChangesAsync(default);
        return true;
    }
}