using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Marketplace.Common;

namespace Marketplace.Features.CreditCards;

[ApiController]
[Route("marketplace/api/v1/[controller]")]
public class CreditCardController(ICreditCardService service) : ControllerBase
{
    private readonly ICreditCardService _service = service;

    [HttpGet]
    [Authorize]
    public async Task<IActionResult> GetAll([FromQuery] ApiGetManyRequest request)
    {
        var result = await _service.GetAllCreditCardsAsync(request);
        return Ok(new ApiGetManyResponse<CreditCardModel>
        {
            Success = true,
            PageNum = request.PageNum,
            PageSize = request.PageSize,
            TotalCount = result.TotalCount,
            Data = result.Data,
            Message = "Credit cards retrieved successfully"
        });
    }

    [HttpGet("{id:Guid}")]
    [Authorize]
    public async Task<IActionResult> Get(Guid id)
    {
        var card = await _service.GetCreditCardAsync(id);
        if (card == null)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Credit card not found" });

        return Ok(new ApiGetOneResponse<CreditCardModel>
        {
            Success = true,
            Data = card,
            Message = "Credit card retrieved successfully"
        });
    }

    [HttpPost]
    [Authorize]
    public async Task<IActionResult> Create([FromQuery] int ownerId, [FromBody] CreditCardFormRequest request)
    {
        var createdCard = await _service.CreateCreditCardAsync(ownerId, request);
        return Ok(new ApiGetOneResponse<CreditCardModel>
        {
            Success = true,
            Data = createdCard,
            Message = "Credit card created successfully"
        });
    }

    [HttpDelete("{id}")]
    [Authorize]
    public async Task<IActionResult> Delete(Guid id)
    {
        var deleted = await _service.DeleteCreditCardAsync(id);
        if (!deleted)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Credit card not found" });

        return Ok(new ApiStatusResponse { Success = true, Code = 200, Message = "Credit card deleted successfully" });
    }
}

