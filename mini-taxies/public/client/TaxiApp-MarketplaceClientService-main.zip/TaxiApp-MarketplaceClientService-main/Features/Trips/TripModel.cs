namespace Marketplace.Features.Trips;



public class TripModel {
    public required Guid Id {get; set;}
    public required Guid DriverName {get; set;}
    public required Guid DriverId {get; set;}
    public required Guid CarLicensePlate {get; set;}
    public required int Price {get; set;}
    public required int Distance {get; set;}

    public required double Latitude {get; set;}
    public required double Longitude {get; set;}
    public required string Status {get; set;}
}

