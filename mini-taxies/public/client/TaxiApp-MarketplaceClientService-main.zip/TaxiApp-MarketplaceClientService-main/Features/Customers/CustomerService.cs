using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Marketplace.Engine;
using Marketplace.Common;

namespace Marketplace.Features.Customers;

public interface ICustomerService
{
    Task<CustomerModel?> GetCustomerAsync(int id);
    Task<(List<CustomerModel> Data, int TotalCount)> GetAllCustomersAsync(ApiGetManyRequest request);
    Task<CustomerModel> CreateCustomerAsync(CustomerModel customer);
    Task<bool> UpdateCustomerAsync(Guid id, CustomerModel customer);
    Task<bool> DeleteCustomerAsync(int id);
}

public class CustomerService(IMarketplaceDbContext dbContext) : ICustomerService
{
    private readonly IMarketplaceDbContext _dbContext = dbContext;

    public async Task<CustomerModel?> GetCustomerAsync(int id)
    {
        return await _dbContext.Customers.FindAsync(id);
    }

    public async Task<(List<CustomerModel> Data, int TotalCount)> GetAllCustomersAsync(ApiGetManyRequest request)
    {
        var query = _dbContext.Customers.AsQueryable();

        if (!string.IsNullOrEmpty(request.Term))
        {
            query = query.Where(c => c.FullName.Contains(request.Term) || c.PhoneNumber.Contains(request.Term));
        }

        int totalCount = await query.CountAsync();

        var data = await query
            .Skip((request.PageNum - 1) * request.PageSize)
            .Take(request.PageSize)
            .ToListAsync();

        return (data, totalCount);
    }

    public async Task<CustomerModel> CreateCustomerAsync(CustomerModel customer)
    {
        _dbContext.Customers.Add(customer);
        await _dbContext.SaveChangesAsync(default);
        return customer;
    }

    public async Task<bool> UpdateCustomerAsync(Guid id, CustomerModel customer)
    {
        var existingCustomer = await _dbContext.Customers.FindAsync(id);
        if (existingCustomer == null)
            return false;

        existingCustomer.FullName = customer.FullName;
        existingCustomer.PhoneNumber = customer.PhoneNumber;

        await _dbContext.SaveChangesAsync(default);
        return true;
    }

    public async Task<bool> DeleteCustomerAsync(int id)
    {
        var existingCustomer = await _dbContext.Customers.FindAsync(id);
        if (existingCustomer == null)
            return false;

        _dbContext.Customers.Remove(existingCustomer);
        await _dbContext.SaveChangesAsync(default);
        return true;
    }
}
