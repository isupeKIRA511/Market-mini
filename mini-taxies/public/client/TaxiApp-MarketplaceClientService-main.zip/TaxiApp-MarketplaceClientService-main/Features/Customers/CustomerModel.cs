namespace Marketplace.Features.Customers;



public class CustomerModel
{
    public required Guid Id {get;  set;}
    public required string FullName { get; set; }
    public required string PhoneNumber {get;  set;}
    public required string PasswordHash {get;  set;}
}

