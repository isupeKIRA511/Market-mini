using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Threading.Tasks;
using Marketplace.Common;

namespace Marketplace.Features.Customers;

[ApiController]
[Route("marketplace/api/v1/[controller]")]
public class CustomerController(ICustomerService service) : ControllerBase
{
    private readonly ICustomerService _service = service;

    [HttpGet]
    [Authorize]
    public async Task<IActionResult> GetAll([FromQuery] ApiGetManyRequest request)
    {
        var result = await _service.GetAllCustomersAsync(request);
        return Ok(new ApiGetManyResponse<CustomerModel>
        {
            Success = true,
            PageNum = request.PageNum,
            PageSize = request.PageSize,
            TotalCount = result.TotalCount,
            Data = result.Data,
            Message = "Customers retrieved successfully"
        });
    }

    [HttpGet("single")]
    [Authorize]
    public async Task<IActionResult> Get([FromQuery] ApiGetOneRequest<int> request)
    {
        var customer = await _service.GetCustomerAsync(request.Id);
        if (customer == null)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Customer not found" });
            
        return Ok(new ApiGetOneResponse<CustomerModel>
        {
            Success = true,
            Data = customer,
            Message = "Customer retrieved successfully"
        });
    }

    [HttpPost]
    [Authorize]
    public async Task<IActionResult> Create([FromBody] CustomerModel customer)
    {
        var createdCustomer = await _service.CreateCustomerAsync(customer);
        return Ok(new ApiGetOneResponse<CustomerModel>
        {
            Success = true,
            Data = createdCustomer,
            Message = "Customer created successfully"
        });
    }

    [HttpPut("{id:guid}")]
    [Authorize]
    public async Task<IActionResult> Update(Guid id, [FromBody] CustomerModel customer)
    {
        if (id != customer.Id)
            return BadRequest(new ApiStatusResponse { Success = false, Code = 400, Message = "ID mismatch" });

        var updated = await _service.UpdateCustomerAsync(id, customer);
        if (!updated)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Customer not found" });

        return Ok(new ApiStatusResponse { Success = true, Code = 200, Message = "Customer updated successfully" });
    }

    [HttpDelete("{id}")]
    [Authorize]
    public async Task<IActionResult> Delete(int id)
    {
        var deleted = await _service.DeleteCustomerAsync(id);
        if (!deleted)
            return NotFound(new ApiStatusResponse { Success = false, Code = 404, Message = "Customer not found" });

        return Ok(new ApiStatusResponse { Success = true, Code = 200, Message = "Customer deleted successfully" });
    }
}
