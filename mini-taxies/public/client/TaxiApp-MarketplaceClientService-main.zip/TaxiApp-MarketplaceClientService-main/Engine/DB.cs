namespace Marketplace.Engine;

using Microsoft.EntityFrameworkCore;
using Marketplace.Features.Customers;
using Marketplace.Features.Banners;
using Marketplace.Features.Banners.Cards;
using Marketplace.Features.CreditCards;
using Marketplace.Features.Companies;
using Marketplace.Features.Cars;

public interface IMarketplaceDbContext
{
    public DbSet<CustomerModel> Customers { get; set; }
    public DbSet<CreditCardModel> CreditCards { get; set; }
    public DbSet<CompanyModel> Companies { get; set; }
    public DbSet<BannerModel> Banners { get; set; }
    public DbSet<BannerCardModel> BannerCards { get; set; }
    public DbSet<CarModel> Cars { get; set; }
    
    Task<int> SaveChangesAsync(CancellationToken cancellationToken);
    int SaveChanges();
}

public class MarketplaceDbContext(DbContextOptions<MarketplaceDbContext> options) : DbContext(options), IMarketplaceDbContext
{
    public required DbSet<CustomerModel> Customers { get; set; }
    public required DbSet<CreditCardModel> CreditCards { get; set; }
    public required DbSet<CompanyModel> Companies { get; set; }
    public required DbSet<BannerModel> Banners { get; set; }
    public required DbSet<BannerCardModel> BannerCards { get; set; }
    public required DbSet<CarModel> Cars { get; set; }

}

