import json
import os
import re
import urllib.request

base_url = input("Enter the URL of the running C# backend (default: http://localhost:5051): ").strip()
if not base_url:
    base_url = "http://localhost:5051"

openapi_url = f"{base_url.rstrip('/')}/openapi/v1.json"
print(f"Fetching OpenAPI spec from {openapi_url}...")

try:
    with urllib.request.urlopen(openapi_url) as response:
        api = json.loads(response.read().decode('utf-8'))
except Exception as e:
    print(f"Error fetching OpenAPI spec: {e}")
    exit(1)

tags_map = {
    'Car': 'Cars',
    'Company': 'Companies',
    'Customer': 'Customers',
    'CreditCard': 'CreditCards',
    'Banner': 'Banners',
    'BannerCard': 'Banners',
    'Auth': 'Auth'
}

def ts_type(schema):
    if not schema: return "any"
    t = schema.get('type')
    if t == 'integer' or t == 'number': return "number"
    if t == 'boolean': return "boolean"
    if t == 'string': return "string"
    if 'type' in schema and type(schema['type']) is list:
        if 'integer' in schema['type']: return "number"
        if 'string' in schema['type']: return "string"
    return "any"

def generate_request_func(path, method, operation, tag):
    func_name_parts = []
    
    path_suffix = path.split(tag)[-1].strip('/')
    if method == 'get':
        if '{id}' in path or '{Id}' in path:
            if 'single' in path: 
                func_name = f"get{tag}Single"
            else:
                func_name = f"get{tag}ById"
        elif path_suffix:
            clean_suffix = re.sub(r'\{.*?\}', '', path_suffix).replace('/', '_').replace('-', '_')
            func_name = f"get{tag}{clean_suffix.title().replace('_', '')}"
        else:
            func_name = f"get{tag}s"
    elif method == 'post':
        if path_suffix:
            clean_suffix = re.sub(r'\{.*?\}', '', path_suffix).replace('/', '_').replace('-', '_')
            func_name = f"post{tag}{clean_suffix.title().replace('_', '')}"
        else:
            func_name = f"create{tag}"
    elif method == 'put':
        func_name = f"update{tag}"
    elif method == 'patch':
        clean_suffix = re.sub(r'\{.*?\}', '', path_suffix).replace('/', '_').replace('-', '_')
        func_name = f"patch{tag}{clean_suffix.title().replace('_', '')}"
    elif method == 'delete':
        func_name = f"delete{tag}"
    else:
        func_name = f"{method}{tag}"
    
    params = operation.get('parameters', [])
    path_args = []
    query_args = []
    
    # Track used argument names to avoid duplicates
    seen = set()
    
    for p in params:
        name = p['name']
        if name in seen: continue
        seen.add(name)
        if p.get('in') == 'path':
            path_args.append(name)
        elif p.get('in') == 'query':
            query_args.append(name)
            
    has_body = 'requestBody' in operation
    
    args_list = []
    for pa in path_args:
        args_list.append(f"{pa}: string | number")
    
    if has_body:
        args_list.append("data: any")
        
    for qa in query_args:
        for p in params:
            if p['name'] == qa:
                t = ts_type(p.get('schema', {}))
                args_list.append(f"{qa}?: {t}")
                break

    # Build the fetch call
    # Replace path templates like {id} with ${id}
    url_template = re.sub(r'\{(.*?)\}', r'${\1}', path)
    url = f"baseURL + `{url_template}`"
    
    if query_args:
        url += " + '?' + new URLSearchParams({"
        for qa in query_args:
            url += f"  ...( {qa} !== undefined ? {{ {qa}: String({qa}) }} : {{}} ),"
        url += "}).toString()"
        
    fetch_opts = [f"method: '{method.upper()}'"]
    
    # some endpoints return empty strings on 200 or 204, need safe parse
    if has_body:
        fetch_opts.append("headers: { 'Content-Type': 'application/json' }")
        fetch_opts.append("body: JSON.stringify(data)")
        
    opts_str = "{\n      " + ",\n      ".join(fetch_opts) + "\n    }"
    
    func_str = f"export const {func_name} = async ({', '.join(args_list)}) => {{\n"
    func_str += f"  const response = await fetch({url}, {opts_str});\n"
    func_str += f"  if (!response.ok) throw new Error('Failed to fetch ' + response.statusText);\n"
    func_str += f"  const text = await response.text();\n"
    func_str += f"  return text ? JSON.parse(text) : null;\n"
    func_str += f"}};\n"
    return func_str

feature_modules = {}

paths = api.get('paths', {})
for path, methods in paths.items():
    for method, op in methods.items():
        if method not in ['get', 'post', 'put', 'delete', 'patch']: continue
        tags = op.get('tags', [])
        if not tags: continue
        tag = tags[0]
        mapped_feature = tags_map.get(tag)
        if not mapped_feature: continue
        
        if mapped_feature not in feature_modules:
            feature_modules[mapped_feature] = []
            
        feature_modules[mapped_feature].append(generate_request_func(path, method, op, tag))

out_dir = "client"
os.makedirs(out_dir, exist_ok=True)

with open(f"{out_dir}/config.ts", 'w') as f:
    f.write(f"export const baseURL = '{base_url.rstrip('/')}';\n")

for feature, funcs in feature_modules.items():
    out_file = f"{out_dir}/{feature}Api.ts"
    with open(out_file, 'w') as f:
        f.write("import { baseURL } from './config';\n\n")
        f.write("\n".join(funcs))
        
print("Done writing API clients in client folder!")
