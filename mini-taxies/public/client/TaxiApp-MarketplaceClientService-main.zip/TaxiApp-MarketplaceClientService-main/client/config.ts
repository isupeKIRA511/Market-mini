export const baseURL = 'http://localhost:5051';
